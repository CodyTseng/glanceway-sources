// sources/codytseng/lobsters/index.ts
var index_default = (api) => {
  return {
    async refresh() {
      const tagConfig = api.config.get("TAG");
      const url = tagConfig ? `https://lobste.rs/t/${tagConfig.split(",").map((t) => t.trim()).filter(Boolean).join(",")}.json` : "https://lobste.rs/hottest.json";
      const response = await api.fetch(url);
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch Lobsters stories (HTTP ${response.status})`);
      }
      api.emit(
        response.json.slice(0, 30).map((story) => ({
          id: story.short_id,
          title: story.title,
          subtitle: story.description || `${story.score} points \xB7 ${story.comment_count} comments \xB7 ${story.tags.join(", ")}`,
          url: story.url || story.comments_url,
          timestamp: story.created_at
        }))
      );
    }
  };
};
module.exports = index_default;