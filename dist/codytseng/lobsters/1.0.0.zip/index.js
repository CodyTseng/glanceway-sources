"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/lobsters/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    const tags = api.config.get("TAG");
    return {
      async refresh() {
        const url = tags && tags.length > 0 ? `https://lobste.rs/t/${tags.join(",")}.json` : "https://lobste.rs/hottest.json";
        const response = await api.fetch(url);
        if (!response.ok || !response.json) {
          throw new Error(`Failed to fetch Lobsters stories (HTTP ${response.status})`);
        }
        api.emit(
          response.json.slice(0, 30).map((story) => ({
            id: story.short_id,
            title: story.title,
            subtitle: story.description || `${story.score} points \xB7 ${story.comment_count} comments \xB7 ${story.tags.join(", ")}`,
            url: story.url || story.comments_url,
            timestamp: story.created_at
          }))
        );
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
