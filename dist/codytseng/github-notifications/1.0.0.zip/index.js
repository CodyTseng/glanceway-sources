"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/github-notifications/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const token = api.config.get("GITHUB_TOKEN");
    const repository = api.config.get("REPOSITORY");
    async function fetchData() {
      const url = repository ? `https://api.github.com/repos/${repository}/notifications?per_page=100` : "https://api.github.com/notifications?per_page=100";
      const response = await api.fetch(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok || !response.json) {
        throw new Error(
          `Failed to fetch GitHub notifications (HTTP ${response.status})`
        );
      }
      const items = response.json.map((item) => {
        const itemUrl = item.subject.url ? item.subject.url.replace("api.github.com/repos", "github.com").replace("/pulls/", "/pull/").replace("/issues/", "/issues/") : null;
        if (!itemUrl) {
          return null;
        }
        return {
          id: item.id,
          title: item.subject.title,
          subtitle: item.repository.full_name,
          url: itemUrl,
          timestamp: item.updated_at
        };
      }).filter(Boolean);
      api.emit(items);
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
