"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/tmdb-trending/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    const apiKey = api.config.get("TMDB_API_KEY");
    const mediaType = api.config.get("MEDIA_TYPE") || "all";
    const timeWindow = api.config.get("TIME_WINDOW") || "week";
    return {
      async refresh() {
        const url = `https://api.themoviedb.org/3/trending/${mediaType}/${timeWindow}?api_key=${apiKey}`;
        const response = await api.fetch(url);
        if (!response.ok || !response.json) {
          throw new Error(`Failed to fetch TMDB trending (HTTP ${response.status})`);
        }
        const items = response.json.results.map((item) => ({
          id: String(item.id),
          title: item.title ?? item.name ?? "Unknown",
          subtitle: item.overview,
          url: `https://www.themoviedb.org/${item.media_type}/${item.id}`,
          timestamp: item.release_date ?? item.first_air_date
        }));
        api.emit(items);
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
