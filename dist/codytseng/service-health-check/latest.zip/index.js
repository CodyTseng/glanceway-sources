"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/service-health-check/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    const urls = api.config.get("URLS");
    return {
      async refresh() {
        if (!urls || urls.length === 0) return;
        const previousDownUrls = new Set(
          JSON.parse(api.storage.get("downUrls") ?? `[]`)
        );
        const currentDownUrls = /* @__PURE__ */ new Set();
        await Promise.allSettled(
          urls.map(async (url) => {
            const res = await api.fetch(url);
            if (!res.ok) {
              currentDownUrls.add(url);
              if (!previousDownUrls.has(url)) {
                api.emit([
                  {
                    id: `${url}-${Date.now()}`,
                    title: `Failed to fetch ${url}`,
                    subtitle: `HTTP ${res.status}, error: ${res.error || "unknown"}`,
                    url,
                    timestamp: Date.now()
                  }
                ]);
              }
            }
          })
        );
        api.storage.set("downUrls", JSON.stringify(Array.from(currentDownUrls)));
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
