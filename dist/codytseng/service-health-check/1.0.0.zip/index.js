// sources/codytseng/service-health-check/index.ts
var index_default = (api) => {
  return {
    async refresh() {
      const urlsConfig = api.config.get("URLS");
      if (!urlsConfig) return;
      const urls = urlsConfig.split(",").map((u) => u.trim()).filter(Boolean);
      const previousDownUrls = new Set(
        JSON.parse(api.storage.get("downUrls") ?? `[]`)
      );
      const currentDownUrls = /* @__PURE__ */ new Set();
      await Promise.all(
        urls.map(async (url) => {
          const res = await api.fetch(url);
          if (!res.ok) {
            currentDownUrls.add(url);
            if (!previousDownUrls.has(url)) {
              api.emit([
                {
                  id: `${url}-${Date.now()}`,
                  title: `Failed to fetch ${url}`,
                  subtitle: `HTTP ${res.status}, error: ${res.error || "unknown"}`,
                  url,
                  timestamp: Date.now()
                }
              ]);
            }
          }
        })
      );
      api.storage.set("downUrls", JSON.stringify(Array.from(currentDownUrls)));
    }
  };
};
module.exports = index_default;