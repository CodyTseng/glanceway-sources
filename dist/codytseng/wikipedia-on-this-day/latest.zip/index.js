"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/wikipedia-on-this-day/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const language = api.config.get("LANGUAGE") || "en";
    async function fetchData() {
      const now = /* @__PURE__ */ new Date();
      const mm = String(now.getMonth() + 1).padStart(2, "0");
      const dd = String(now.getDate()).padStart(2, "0");
      const url = `https://api.wikimedia.org/feed/v1/wikipedia/${language}/onthisday/all/${mm}/${dd}`;
      const response = await api.fetch(url);
      if (!response.ok || !response.json) {
        throw new Error(
          `Failed to fetch Wikipedia On This Day (HTTP ${response.status})`
        );
      }
      const events = [
        ...response.json.selected || [],
        ...response.json.events || []
      ];
      const seen = /* @__PURE__ */ new Set();
      const items = [];
      for (const item of events) {
        const page = item.pages?.[0];
        const id = `${item.year}-${page?.title || item.text.slice(0, 50)}`;
        if (seen.has(id)) continue;
        seen.add(id);
        items.push({
          id,
          title: `${item.year} \u2014 ${item.text}`,
          subtitle: page?.extract,
          url: page?.content_urls?.desktop?.page
        });
        if (items.length >= 200) break;
      }
      api.emit(items);
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
