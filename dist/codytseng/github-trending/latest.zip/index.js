// sources/codytseng/github-trending/index.ts
var index_default = (api) => {
  return {
    async refresh() {
      const language = api.config.get("LANGUAGE");
      const since = /* @__PURE__ */ new Date();
      since.setDate(since.getDate() - 7);
      const sinceStr = since.toISOString().split("T")[0];
      let query = `created:>${sinceStr} stars:>5`;
      if (language) {
        query += ` language:${language}`;
      }
      const response = await api.fetch(
        `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=30`
      );
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch GitHub trending repositories (HTTP ${response.status})`);
      }
      api.emit(
        response.json.items.map((repo) => {
          return {
            id: repo.id.toString(),
            title: repo.full_name,
            subtitle: repo.description || `${repo.language ?? "Unknown"} \xB7 ${repo.stargazers_count} stars`,
            url: repo.html_url
          };
        })
      );
    }
  };
};
module.exports = index_default;