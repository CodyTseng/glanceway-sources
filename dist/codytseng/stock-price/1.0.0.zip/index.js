"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/stock-price/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const token = api.config.get("FINNHUB_TOKEN");
    const symbolsRaw = api.config.get("SYMBOLS") ?? [];
    async function fetchData() {
      const symbols = symbolsRaw.map((s) => s.toUpperCase());
      if (symbols.length === 0) {
        api.emit([]);
        return;
      }
      const items = [];
      for (const symbol of symbols) {
        const quoteRes = await api.fetch(
          `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${token}`
        );
        if (!quoteRes.ok || !quoteRes.json || quoteRes.json.c === 0) {
          api.log("warn", `Failed to fetch quote for ${symbol}`);
          continue;
        }
        const q = quoteRes.json;
        let name = api.storage.get(`name:${symbol}`);
        if (!name) {
          const profileRes = await api.fetch(
            `https://finnhub.io/api/v1/stock/profile2?symbol=${symbol}&token=${token}`
          );
          if (profileRes.ok && profileRes.json?.name) {
            name = profileRes.json.name;
            api.storage.set(`name:${symbol}`, name);
          }
        }
        const price = q.c.toFixed(2);
        const change = q.d.toFixed(2);
        const changePct = q.dp.toFixed(2);
        const arrow = q.d > 0 ? "\u2191" : q.d < 0 ? "\u2193" : "";
        const sign = q.d > 0 ? "+" : "";
        items.push({
          id: symbol,
          title: name ? `${name} (${symbol})` : symbol,
          subtitle: `${price} ${arrow} ${sign}${change} (${sign}${changePct}%)`,
          url: `https://finnhub.io/stock/${symbol}`
        });
      }
      api.emit(items);
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
