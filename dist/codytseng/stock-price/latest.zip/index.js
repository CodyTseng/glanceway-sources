// sources/codytseng/stock-price/index.ts
var index_default = (api) => {
  const token = api.config.get("FINNHUB_TOKEN");
  const symbolsRaw = api.config.get("SYMBOLS") ?? [];
  return {
    async refresh() {
      const symbols = symbolsRaw.map((s) => s.toUpperCase());
      if (symbols.length === 0) {
        api.emit([]);
        return;
      }
      const items = [];
      for (const symbol of symbols) {
        const quoteRes = await api.fetch(
          `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${token}`
        );
        if (!quoteRes.ok || !quoteRes.json || quoteRes.json.c === 0) {
          api.log("warn", `Failed to fetch quote for ${symbol}`);
          continue;
        }
        const q = quoteRes.json;
        let name = api.storage.get(`name:${symbol}`);
        if (!name) {
          const profileRes = await api.fetch(
            `https://finnhub.io/api/v1/stock/profile2?symbol=${symbol}&token=${token}`
          );
          if (profileRes.ok && profileRes.json?.name) {
            name = profileRes.json.name;
            api.storage.set(`name:${symbol}`, name);
          }
        }
        const price = q.c.toFixed(2);
        const change = q.d.toFixed(2);
        const changePct = q.dp.toFixed(2);
        const arrow = q.d > 0 ? "\u2191" : q.d < 0 ? "\u2193" : "";
        const sign = q.d > 0 ? "+" : "";
        items.push({
          id: symbol,
          title: name ? `${name} (${symbol})` : symbol,
          subtitle: `${price} ${arrow} ${sign}${change} (${sign}${changePct}%)`,
          url: `https://finnhub.io/stock/${symbol}`
        });
      }
      api.emit(items);
    }
  };
};
module.exports = index_default;