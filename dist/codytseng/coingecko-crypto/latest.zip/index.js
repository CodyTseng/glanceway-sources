// sources/codytseng/coingecko-crypto/index.ts
var index_default = (api) => {
  const currency = api.config.get("CURRENCY") || "usd";
  const order = api.config.get("ORDER") || "market_cap_desc";
  return {
    async refresh() {
      const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=${currency}&order=${order}&per_page=25&sparkline=false`;
      const response = await api.fetch(url);
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch CoinGecko market data (HTTP ${response.status})`);
      }
      const now = Date.now();
      const items = response.json.map((item, i) => {
        const change = item.price_change_percentage_24h;
        const changeStr = change != null ? ` ${change > 0 ? "+" : ""}${change.toFixed(2)}%` : "";
        return {
          id: item.id,
          title: `${item.name} (${item.symbol.toUpperCase()})`,
          subtitle: `${currencySymbol(currency)}${item.current_price.toLocaleString("en-US")}${changeStr}`,
          url: `https://www.coingecko.com/en/coins/${item.id}`,
          timestamp: now - i
        };
      });
      api.emit(items);
    }
  };
};
function currencySymbol(currency) {
  switch (currency) {
    case "usd":
      return "$";
    case "eur":
      return "\u20AC";
    case "gbp":
      return "\xA3";
    case "jpy":
      return "\xA5";
    case "cny":
      return "\xA5";
    default:
      return "";
  }
}
module.exports = index_default;