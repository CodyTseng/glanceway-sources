"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/stackoverflow-hot/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const tags = api.config.get("TAG") ?? [];
    const sort = api.config.get("SORT") || "hot";
    async function fetchData() {
      const toItems = (questions) => questions.map((q) => ({
        id: q.question_id.toString(),
        title: q.title,
        subtitle: `${q.score} votes \xB7 ${q.answer_count} answers \xB7 ${q.tags.slice(0, 3).join(", ")}`,
        url: q.link,
        timestamp: q.creation_date
      }));
      if (tags.length > 0) {
        const pageSize = Math.min(100, Math.floor(500 / tags.length));
        await Promise.allSettled(
          tags.map(async (tag) => {
            const res = await api.fetch(
              `https://api.stackexchange.com/2.3/questions?order=desc&sort=${sort}&site=stackoverflow&pagesize=${pageSize}&tagged=${encodeURIComponent(tag)}`
            );
            if (res.ok && res.json) {
              api.emit(toItems(res.json.items));
            }
          })
        );
      } else {
        const res = await api.fetch(
          `https://api.stackexchange.com/2.3/questions?order=desc&sort=${sort}&site=stackoverflow&pagesize=100`
        );
        if (!res.ok || !res.json) {
          throw new Error(`Failed to fetch Stack Overflow questions (HTTP ${res.status})`);
        }
        api.emit(toItems(res.json.items));
      }
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
