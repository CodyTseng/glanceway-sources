"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/reddit/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const subreddits = api.config.get("SUBREDDIT") ?? ["programming"];
    const subreddit = subreddits.join("+");
    const sort = api.config.get("SORT") || "hot";
    async function fetchData() {
      const response = await api.fetch(`https://www.reddit.com/r/${subreddit}/${sort}.json?limit=100&raw_json=1`, {
        headers: { "User-Agent": "Glanceway/1.0" }
      });
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch Reddit posts from r/${subreddit} (HTTP ${response.status})`);
      }
      api.emit(
        response.json.data.children.map((child) => {
          const post = child.data;
          return {
            id: post.id,
            title: post.title,
            subtitle: post.selftext || `\u2191 ${post.score} \xB7 ${post.num_comments} comments \xB7 u/${post.author}`,
            url: post.url.startsWith("/") ? `https://www.reddit.com${post.url}` : post.url,
            timestamp: post.created_utc
          };
        })
      );
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
