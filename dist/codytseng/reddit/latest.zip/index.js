// sources/codytseng/reddit/index.ts
var index_default = (api) => {
  return {
    async refresh() {
      const subreddits = api.config.get("SUBREDDIT") ?? ["programming"];
      const subreddit = subreddits.join("+");
      const sort = api.config.get("SORT") || "hot";
      const response = await api.fetch(`https://www.reddit.com/r/${subreddit}/${sort}.json?limit=30&raw_json=1`, {
        headers: { "User-Agent": "Glanceway/1.0" }
      });
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch Reddit posts from r/${subreddit} (HTTP ${response.status})`);
      }
      api.emit(
        response.json.data.children.map((child) => {
          const post = child.data;
          return {
            id: post.id,
            title: post.title,
            subtitle: post.selftext || `\u2191 ${post.score} \xB7 ${post.num_comments} comments \xB7 u/${post.author}`,
            url: post.url.startsWith("/") ? `https://www.reddit.com${post.url}` : post.url,
            timestamp: post.created_utc
          };
        })
      );
    }
  };
};
module.exports = index_default;