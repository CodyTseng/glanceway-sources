"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/v2ex/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    const nodes = api.config.get("NODE_NAME") ?? [];
    return {
      async refresh() {
        const toItems = (topics) => topics.map((topic) => ({
          id: topic.id.toString(),
          title: topic.title,
          subtitle: `${topic.node.title} \xB7 ${topic.replies} \u56DE\u590D \xB7 ${topic.member.username}`,
          url: topic.url,
          timestamp: topic.created
        }));
        if (nodes.length > 0) {
          await Promise.allSettled(
            nodes.map(async (node) => {
              const res = await api.fetch(
                `https://www.v2ex.com/api/topics/show.json?node_name=${encodeURIComponent(node)}`
              );
              if (res.ok && res.json) {
                api.emit(toItems(res.json));
              }
            })
          );
        } else {
          const res = await api.fetch(
            "https://www.v2ex.com/api/topics/hot.json"
          );
          if (!res.ok || !res.json) {
            throw new Error(`Failed to fetch V2EX hot topics (HTTP ${res.status})`);
          }
          api.emit(toItems(res.json));
        }
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
