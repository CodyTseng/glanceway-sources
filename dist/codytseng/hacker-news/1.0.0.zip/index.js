"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/hacker-news/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const storyType = api.config.get("STORY_TYPE") || "top";
    async function fetchData() {
      const endpoint = `https://hacker-news.firebaseio.com/v0/${storyType}stories.json`;
      const idsResponse = await api.fetch(endpoint);
      if (!idsResponse.ok || !idsResponse.json) {
        throw new Error(`Failed to fetch Hacker News story list (HTTP ${idsResponse.status})`);
      }
      const topIds = idsResponse.json.slice(0, 100);
      const items = [];
      await Promise.allSettled(
        topIds.map(async (id) => {
          const res = await api.fetch(
            `https://hacker-news.firebaseio.com/v0/item/${id}.json`
          );
          if (res.json) {
            items.push(res.json);
            api.emit(
              items.map((item) => ({
                id: item.id.toString(),
                title: item.title,
                subtitle: `${item.score} points \xB7 ${item.descendants ?? 0} comments \xB7 by ${item.by}`,
                url: item.url ?? `https://news.ycombinator.com/item?id=${item.id}`,
                timestamp: item.time
              }))
            );
          }
        })
      );
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
