"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/dev-to/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    const tags = api.config.get("TAG") ?? [];
    return {
      async refresh() {
        const toItems = (articles) => articles.map((article) => ({
          id: article.id.toString(),
          title: article.title,
          subtitle: article.description || `${article.positive_reactions_count} reactions \xB7 ${article.comments_count} comments`,
          url: article.url,
          timestamp: article.published_at
        }));
        if (tags.length > 0) {
          const perPage = Math.min(30, Math.floor(150 / tags.length));
          await Promise.allSettled(
            tags.map(async (tag) => {
              const res = await api.fetch(
                `https://dev.to/api/articles?per_page=${perPage}&top=7&tag=${encodeURIComponent(tag)}`
              );
              if (res.ok && res.json) {
                api.emit(toItems(res.json));
              }
            })
          );
        } else {
          const res = await api.fetch(
            "https://dev.to/api/articles?per_page=30&top=7"
          );
          if (!res.ok || !res.json) {
            throw new Error(`Failed to fetch DEV articles (HTTP ${res.status})`);
          }
          api.emit(toItems(res.json));
        }
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
