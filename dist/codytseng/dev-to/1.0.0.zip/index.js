// sources/codytseng/dev-to/index.ts
var index_default = (api) => {
  return {
    async refresh() {
      const tags = api.config.get("TAG") ?? [];
      const toItems = (articles) => articles.map((article) => ({
        id: article.id.toString(),
        title: article.title,
        subtitle: article.description || `${article.positive_reactions_count} reactions \xB7 ${article.comments_count} comments`,
        url: article.url,
        timestamp: article.published_at
      }));
      if (tags.length > 0) {
        const perPage = Math.min(30, Math.floor(150 / tags.length));
        await Promise.all(
          tags.map(async (tag) => {
            const res = await api.fetch(
              `https://dev.to/api/articles?per_page=${perPage}&top=7&tag=${encodeURIComponent(tag)}`
            );
            if (!res.ok || !res.json) {
              throw new Error(`Failed to fetch DEV articles for tag "${tag}" (HTTP ${res.status})`);
            }
            api.emit(toItems(res.json));
          })
        );
      } else {
        const res = await api.fetch(
          "https://dev.to/api/articles?per_page=30&top=7"
        );
        if (!res.ok || !res.json) {
          throw new Error(`Failed to fetch DEV articles (HTTP ${res.status})`);
        }
        api.emit(toItems(res.json));
      }
    }
  };
};
module.exports = index_default;