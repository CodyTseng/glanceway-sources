"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/cn-stock-price/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  function toSecId(code) {
    const c = code.trim();
    if (c.startsWith("6")) return `1.${c}`;
    return `0.${c}`;
  }
  function marketLabel(market) {
    return market === 1 ? "SH" : "SZ";
  }
  var index_default = (api) => {
    const codes = api.config.get("STOCK_CODES") ?? [];
    return {
      async refresh() {
        if (codes.length === 0) {
          api.emit([]);
          return;
        }
        const secIds = codes.map(toSecId).join(",");
        const url = `https://push2.eastmoney.com/api/qt/ulist.np/get?secids=${secIds}&fields=f1,f2,f3,f4,f12,f13,f14`;
        const response = await api.fetch(url);
        if (!response.ok || !response.json?.data?.diff) {
          throw new Error(
            `Failed to fetch stock data (HTTP ${response.status})`
          );
        }
        const items = response.json.data.diff.map((stock) => {
          const precision = stock.f1;
          const divisor = Math.pow(10, precision);
          const priceVal = stock.f2 / divisor;
          const changeVal = stock.f4 / divisor;
          const changePctVal = stock.f3 / divisor;
          const arrow = changePctVal > 0 ? "\u2191" : changePctVal < 0 ? "\u2193" : "";
          const sign = changePctVal > 0 ? "+" : "";
          const ml = marketLabel(stock.f13);
          const price = priceVal.toFixed(precision);
          const change = changeVal.toFixed(precision);
          const changePct = changePctVal.toFixed(2);
          return {
            id: `${ml}${stock.f12}`,
            title: `${stock.f14} (${ml}${stock.f12})`,
            subtitle: `${price} ${arrow} ${sign}${change} (${sign}${changePct}%)`,
            url: `https://quote.eastmoney.com/${ml.toLowerCase()}${stock.f12}.html`
          };
        });
        api.emit(items);
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
