"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/xkcd/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = (api) => {
    return {
      async refresh() {
        const latestRes = await api.fetch(
          "https://xkcd.com/info.0.json"
        );
        if (!latestRes.ok || !latestRes.json) {
          throw new Error(`Failed to fetch latest xkcd comic (HTTP ${latestRes.status})`);
        }
        const latest = latestRes.json;
        const count = 20;
        const comics = [latest];
        await Promise.allSettled(
          Array.from({ length: count - 1 }, (_, i) => latest.num - i - 1).filter((num) => num > 0 && num !== 404).map(async (num) => {
            const res = await api.fetch(
              `https://xkcd.com/${num}/info.0.json`
            );
            if (res.ok && res.json) {
              comics.push(res.json);
              api.emit(
                comics.map((c) => ({
                  id: c.num.toString(),
                  title: `#${c.num}: ${c.title}`,
                  subtitle: c.alt,
                  url: `https://xkcd.com/${c.num}/`,
                  timestamp: `${c.year}-${c.month.padStart(2, "0")}-${c.day.padStart(2, "0")}`
                }))
              );
            }
          })
        );
      }
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
