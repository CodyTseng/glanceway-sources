"use strict";
var _source = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // sources/codytseng/product-hunt/index.ts
  var index_exports = {};
  __export(index_exports, {
    default: () => index_default
  });
  var index_default = async (api) => {
    const token = api.config.get("API_TOKEN");
    async function fetchData() {
      const query = `{
      posts(order: RANKING) {
        edges {
          node {
            id
            name
            tagline
            url
            votesCount
            createdAt
          }
        }
      }
    }`;
      const response = await api.fetch("https://api.producthunt.com/v2/api/graphql", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ query })
      });
      if (!response.ok || !response.json) {
        throw new Error(`Failed to fetch Product Hunt posts (HTTP ${response.status})`);
      }
      api.emit(
        response.json.data.posts.edges.map((edge) => ({
          id: edge.node.id,
          title: edge.node.name,
          subtitle: edge.node.tagline,
          url: edge.node.url,
          timestamp: edge.node.createdAt
        }))
      );
    }
    await fetchData();
    return {
      refresh: fetchData
    };
  };
  return __toCommonJS(index_exports);
})();
module.exports = _source.default;
